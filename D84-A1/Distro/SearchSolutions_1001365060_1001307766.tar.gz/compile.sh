g++ -c -g -O3 AI_search.c
g++ -g *.o -lm -lglut -lGL -lGLU -lX11 -o AI_search

